<?php

//Basics of config file
DataObject::add_extension('SiteTree', 'SSPaypalBasic');
